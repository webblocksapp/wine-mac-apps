#!/bin/bash
$WINE_APP_SCRIPTS_PATH/wine.sh taskmgr
